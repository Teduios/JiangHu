//
//  SXTabBar.m
//  BaseProject
//
//  Created by tarena on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SXTabBar.h"
@interface SXTabBar()
@property(nonatomic,strong)UIImageView *imageView;
@end
@implementation SXTabBar

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
